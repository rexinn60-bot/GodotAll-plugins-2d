@tool
extends EditorPlugin

var up_button: Button
var down_button: Button

func _enter_tree() -> void:
	up_button = Button.new()
	up_button.text = "⬆"
	up_button.tooltip_text = "上移节点 (Ctrl+Up)"
	up_button.focus_mode = Control.FOCUS_NONE
	up_button.pressed.connect(_on_move_up)
	add_control_to_container(EditorPlugin.CONTAINER_CANVAS_EDITOR_MENU, up_button)

	down_button = Button.new()
	down_button.text = "⬇"
	down_button.tooltip_text = "下移节点 (Ctrl+Down)"
	down_button.focus_mode = Control.FOCUS_NONE
	down_button.pressed.connect(_on_move_down)
	add_control_to_container(EditorPlugin.CONTAINER_CANVAS_EDITOR_MENU, down_button)


func _exit_tree() -> void:
	if is_instance_valid(up_button):
		remove_control_from_container(EditorPlugin.CONTAINER_CANVAS_EDITOR_MENU, up_button)
		up_button.queue_free()
	if is_instance_valid(down_button):
		remove_control_from_container(EditorPlugin.CONTAINER_CANVAS_EDITOR_MENU, down_button)
		down_button.queue_free()


func _on_move_up() -> void:
	_move_selected(-1)


func _on_move_down() -> void:
	_move_selected(1)


func _move_selected(direction: int) -> void:
	var selection := get_editor_interface().get_selection()
	var selected := selection.get_selected_nodes()
	if selected.is_empty():
		return

	var undo := get_undo_redo()
	undo.create_action("移动节点层级")

	for node in selected:
		var parent := node.get_parent()
		if parent == null:
			continue
		var idx := node.get_index()
		var new_idx := clampi(idx + direction, 0, parent.get_child_count() - 1)
		if new_idx == idx:
			continue
		undo.add_do_method(parent, "move_child", node, new_idx)
		undo.add_undo_method(parent, "move_child", node, idx)

	undo.commit_action()

	selection.clear()
	for node in selected:
		if is_instance_valid(node):
			selection.add_node(node)
